<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Veiculos;
use Illuminate\Support\Facades\DB;

class VeiculoController extends Controller
{
    public function listVeiculo(){
        $veiculos = Veiculos::orderBy('id', 'DESC')->get();
        return view('index', compact('veiculos'));
    }

    public function createVeiculo(Request $request){
        try {
            //Cria Veiculo
            $data['modelo'] = $request->modelo;
            $data['anoFabricacao'] = $request->anoFabricacao;
            $data['placa'] = $request->placa;
            $veiculo = Veiculos::create($data);
            //Cria Acessorio
            $acessorio = DB::table('acessorios')->insert([
                'nome' => $request->nome,
                'veiculo_id' => $veiculo->id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            //Retorno
            $message = 'Veiculo criado com sucesso!';
            $code = 'success';

            $veiculos = Veiculos::orderBy('id', 'DESC')->get();
            return view('index', compact('veiculos', 'message', 'code'));
        } catch (\Throwable $th) {
            $message = 'Erro ao criar veiculo!';
            $code = 'danger';

            return view('index', compact('message', 'code'));
        }
    }

    public function updateVeiculo(Request $request, $id){
        try {
            $veiculo = Veiculos::where('id', '=', $id)->first();
            $veiculo->modelo = $request->modelo;
            $veiculo->anoFabricacao = $request->anoFabricacao;
            $veiculo->placa = $request->placa;
            $veiculo->save();
            $message = 'Veiculo alterado com sucesso!';
        } catch (\Throwable $th) {
            $message = 'Erro ao alterar veiculo!';
        }

        return view('index', compact('message'));
    }

    public function deleteVeiculo($id){
        try {
            $veiculo = Veiculos::where($id)->first();
            $veiculo->delete();
            $message = 'Veiculo excluido com sucesso!';
        } catch (\Throwable $th) {
            $message = 'Erro ao excluir veiculo!';
        }

        return view('index', compact('message'));
    }
}

<div>
    <table>
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Modelo</th>
                <th scope="col">Ano de Fabricacao</th>
                <th scope="col">Placa</th>
                <th scope="col">Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($veiculos)) {
                foreach ($veiculos as $veiculo) { ?>
                    <tr>
                        <th scope="row"><?= $veiculo['id']?></th>
                        <td><?= $veiculo['modelo']?></td>
                        <td><?= $veiculo['anoFabricacao']?></td>
                        <td><?= $veiculo['placa']?></td>
                        <td><a href="">Excluir</a></td>
                    </tr><?php
                }
            }else{
                ?>
                <tr>
                    <th colspan="5">Nenhum Veiculo cadastrado</th>
                </tr>
                <?php
            }?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\zzz-escola-ti\prova\tema1\resources\views/components/list-veiculos.blade.php ENDPATH**/ ?>
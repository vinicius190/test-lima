<div>
    <table class="w3-table-all">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($acessorios)) {
                foreach ($acessorios as $acessorio) { ?>
                    <tr>
                        <th scope="row"><?= $acessorio['id']?></th>
                        <td><?= $acessorio['nome']?></td>
                    </tr><?php
                }
            }else{
                ?>
                <tr>
                    <th colspan="2">Nenhum acessorio cadastrado</th>
                </tr>
                <?php
            }?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\zzz-escola-ti\prova\tema1\resources\views/components/list-acessorios.blade.php ENDPATH**/ ?>
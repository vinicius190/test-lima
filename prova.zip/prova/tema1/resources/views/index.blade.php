<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            margin: 3px;
        }
        div{
            align-items: center;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .alert-danger {
            padding: 20px;
            background-color: #f44336;
            color: white;
        }
        .alert-success {
            padding: 20px;
            background-color: #4cf436;
            color: white;
        }
        .closebtn {
            margin-left: 15px;
            color: white;
            font-weight: bold;
            float: right;
            font-size: 22px;
            line-height: 20px;
            cursor: pointer;
            transition: 0.3s;
        }
        .closebtn:hover {
            color: black;
        }
        .button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    @if (isset($message))
        <div class="alert-{{ $code }}">
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
            <strong>{{ $message }}!</strong>
        </div>
    @endif
    <a class="button" href="{{ route('form.veiculos') }}">Adicionar Veiculo</a>
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Modelo</th>
                    <th scope="col">Ano de Fabricacao</th>
                    <th scope="col">Placa</th>
                    <th scope="col">Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($veiculos)) {
                    foreach ($veiculos as $veiculo) { ?>
                        <tr>
                            <th scope="row"><?= $veiculo['id']?></th>
                            <td><?= $veiculo['modelo']?></td>
                            <td><?= $veiculo['anoFabricacao']?></td>
                            <td><?= $veiculo['placa']?></td>
                            <td><a href="">Excluir</a></td>
                        </tr><?php
                    }
                }?>
            </tbody>
        </table>
    </div>
</body>
</html>

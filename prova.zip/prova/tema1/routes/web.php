<?php

use App\Http\Controllers\AcessorioController;
use App\Http\Controllers\VeiculoController;
use Illuminate\Support\Facades\Route;

Route::get('/form-veiculos', function () {
    return view('form-veiculos');
})->name('form.veiculos');

Route::get('/', [VeiculoController::class, 'listVeiculo'])->name('list.veiculos');
Route::post('/veiculos', [VeiculoController::class, 'createVeiculo'])->name('create.veiculos');
Route::put('/veiculos/{id}', [VeiculoController::class, 'updateVeiculo'])->name('update.veiculos');
Route::delete('/veiculos', [VeiculoController::class, 'deleteVeiculo'])->name('delete.veiculos');
